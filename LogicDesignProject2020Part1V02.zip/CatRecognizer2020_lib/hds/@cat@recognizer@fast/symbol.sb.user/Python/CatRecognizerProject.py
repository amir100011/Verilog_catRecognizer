import matplotlib.pyplot as plt
import scipy
from scipy import ndimage
import os
import numpy as np
import h5py

WeightPrecisionOptions = [5]
# ---------------------- parameters of the digital system----------
WEIGHT_BIAS_PRECISION = WeightPrecisionOptions[0]
NUMBER_OF_PIXELS = 8
PIXEL_PRECISION = 2
PIXEL_PRECISION_PLUS_WEIGHT_BIAS_PRECISION = PIXEL_PRECISION + WEIGHT_BIAS_PRECISION
#%% parameter set of the design

# ---------------------- parameters of the digital system----------


def load_dataset():
    train_dataset = h5py.File('datasets/train_catvnoncat.h5', "r")
    train_set_x_orig = np.array(train_dataset["train_set_x"][:])  # your train set features
    train_set_y_orig = np.array(train_dataset["train_set_y"][:])  # your train set labels

    test_dataset = h5py.File('datasets/test_catvnoncat.h5', "r")
    test_set_x_orig = np.array(test_dataset["test_set_x"][:])  # your test set features
    test_set_y_orig = np.array(test_dataset["test_set_y"][:])  # your test set labels

    classes = np.array(test_dataset["list_classes"][:])  # the list of classes

    train_set_y_orig = train_set_y_orig.reshape((1, train_set_y_orig.shape[0]))
    test_set_y_orig = test_set_y_orig.reshape((1, test_set_y_orig.shape[0]))

    return train_set_x_orig, train_set_y_orig, test_set_x_orig, test_set_y_orig, classes
# Loading the data (cat/non-cat)
train_set_x_orig, train_set_y, test_set_x_orig, test_set_y, classes = load_dataset()


m_train = train_set_x_orig.shape[0]
m_test = test_set_x_orig.shape[0]
num_px = test_set_x_orig.shape[1]

# Reshape the training and test examples
train_set_x_flatten = train_set_x_orig.reshape(train_set_x_orig.shape[0],-1).T
test_set_x_flatten = test_set_x_orig.reshape(test_set_x_orig.shape[0],-1).T

train_set_x = train_set_x_flatten/255.
test_set_x = test_set_x_flatten/255.

# global max_z, min_z, PIXEL_PRECISION_PLUS_WEIGHT_BIAS_PRECISION


def sigmoid(z):
    """
    Compute the sigmoid of z

    Arguments:
    z -- A scalar or numpy array of any size.

    Return:
    s -- sigmoid(z)
    """
    # # find the maximum and minimum values for later quantization
    # global max_z, min_z, PIXEL_PRECISION_PLUS_WEIGHT_BIAS_PRECISION
    # if max_z < np.max(z):
    #         max_z = np.max(z)
    # if min_z > np.min(z):
    #         min_z = np.min(z)
    # # find the maximum and minimum values for later quantization

    s = 1/(1+np.exp(-z))
    return s
	

def initialize_with_zeros(dim):
    """
    This function creates a vector of zeros of shape (dim, 1) for w and initializes b to 0.
    
    Argument:
    dim -- size of the w vector we want (or number of parameters in this case)
    
    Returns:
    w -- initialized vector of shape (dim, 1)
    b -- initialized scalar (corresponds to the bias)
    """
    
    w = np.zeros((dim,1),dtype=float)
    b = 0

    assert(w.shape == (dim, 1))
    assert(isinstance(b, float) or isinstance(b, int))
    
    return w, b

def propagate(w, b, X, Y):
    """
    Implement the cost function and its gradient for the propagation explained above

    Arguments:
    w -- weights, a numpy array of size (num_px * num_px * 3, 1)
    b -- bias, a scalar
    X -- data of size (num_px * num_px * 3, number of examples)
    Y -- true "label" vector (containing 0 if non-cat, 1 if cat) of size (1, number of examples)

    Return:
    cost -- negative log-likelihood cost for logistic regression
    dw -- gradient of the loss with respect to w, thus same shape as w
    db -- gradient of the loss with respect to b, thus same shape as b
    
    Tips:
    - Write your code step by step for the propagation. np.log(), np.dot()
    """
    
    m = X.shape[1]
    # FORWARD PROPAGATION (FROM X TO COST)
    A = sigmoid(np.dot(w.T,X)+b)  
    cost = -(1/float(m))*np.sum(Y*np.log(A)+(1-Y)*np.log(1-A),1)           # compute cost
    
    # BACKWARD PROPAGATION (TO FIND GRAD)
    dw = (1/float(m))*np.dot(X,(A-Y).T)
    db = (1/float(m))*np.sum(A-Y,1)

    assert(dw.shape == w.shape)
    assert(db.dtype == float)
    cost = np.squeeze(cost)
    assert(cost.shape == ())
    
    grads = {"dw": dw,
             "db": db}
    
    return grads, cost

def optimize(w, b, X, Y, num_iterations, learning_rate, print_cost = False):
    """
    This function optimizes w and b by running a gradient descent algorithm
    
    Arguments:
    w -- weights, a numpy array of size (num_px * num_px * 3, 1)
    b -- bias, a scalar
    X -- data of shape (num_px * num_px * 3, number of examples)
    Y -- true "label" vector (containing 0 if non-cat, 1 if cat), of shape (1, number of examples)
    num_iterations -- number of iterations of the optimization loop
    learning_rate -- learning rate of the gradient descent update rule
    print_cost -- True to print the loss every 100 steps
    
    Returns:
    params -- dictionary containing the weights w and bias b
    grads -- dictionary containing the gradients of the weights and bias with respect to the cost function
    costs -- list of all the costs computed during the optimization, this will be used to plot the learning curve.
    
    Tips:
    You basically need to write down two steps and iterate through them:
        1) Calculate the cost and the gradient for the current parameters. Use propagate().
        2) Update the parameters using gradient descent rule for w and b.
    """
    costs = []
    
    for i in range(num_iterations):
             
        # Cost and gradient calculation (≈ 1-4 lines of code)
        grads, cost = propagate(w, b, X, Y)
        
        # Retrieve derivatives from grads
        dw = grads["dw"]
        db = grads["db"]
        
        # update rule (≈ 2 lines of code)
        w = w - learning_rate*dw
        b = b - learning_rate*db
        
        # Record the costs
        if i % 100 == 0:
            costs.append(cost)
        
        # Print the cost every 100 training iterations
        if print_cost and i % 100 == 0:
            print ("Cost after iteration %i: %f" %(i, cost))
    
    params = {"w": w,
              "b": b}
    
    grads = {"dw": dw,
             "db": db}
    
    return params, grads, costs
	
def predict(w, b, X):
    '''
    Predict whether the label is 0 or 1 using learned logistic regression parameters (w, b)
    
    Arguments:
    w -- weights, a numpy array of size (num_px * num_px * 3, 1)
    b -- bias, a scalar
    X -- data of size (num_px * num_px * 3, number of examples)
    
    Returns:
    Y_prediction -- a numpy array (vector) containing all predictions (0/1) for the examples in X
    '''

    m = X.shape[1]
    Y_prediction = np.zeros((1,m))
    w = w.reshape(X.shape[0], 1)
    
    # Compute vector "A" predicting the probabilities of a cat being present in the picture
    A=sigmoid(np.dot(w.T,(X+b))) 
    
    for i in range(A.shape[1]):
        
        # Convert probabilities A[0,i] to actual predictions p[0,i]
        if A[0,i]>0.5:
           Y_prediction[0,i]=1 
    
    assert(Y_prediction.shape == (1, m))
    
    return Y_prediction


def model(X_train, Y_train, X_test, Y_test, num_iterations = 2000, learning_rate = 0.5, print_cost = False):
    """
    Builds the logistic regression model by calling the function you've implemented previously
    
    Arguments:
    X_train -- training set represented by a numpy array of shape (num_px * num_px * 3, m_train)
    Y_train -- training labels represented by a numpy array (vector) of shape (1, m_train)
    X_test -- test set represented by a numpy array of shape (num_px * num_px * 3, m_test)
    Y_test -- test labels represented by a numpy array (vector) of shape (1, m_test)
    num_iterations -- hyperparameter representing the number of iterations to optimize the parameters
    learning_rate -- hyperparameter representing the learning rate used in the update rule of optimize()
    print_cost -- Set to true to print the cost every 100 iterations
    
    Returns:
    d -- dictionary containing information about the model.
    """
    
    
    # initialize parameters with zeros (≈ 1 line of code)
    w, b = initialize_with_zeros(train_set_x_flatten.shape[0])
    # Gradient descent (≈ 1 line of code)
    parameters, grads, costs = optimize(w, b, X_train, Y_train, num_iterations, learning_rate = 0.009, print_cost = False)
    
    # Retrieve parameters w and b from dictionary "parameters"
    w = parameters["w"]
    b = parameters["b"]
    
    # Predict test/train set examples (≈ 2 lines of code)
    Y_prediction_test = predict(w, b, X_test)
    Y_prediction_train = predict(w, b, X_train)


    d = {"costs": costs,
         "Y_prediction_test": Y_prediction_test, 
         "Y_prediction_train" : Y_prediction_train, 
         "w" : w, 
         "b" : b,
         "learning_rate" : learning_rate,
         "num_iterations": num_iterations}
    
    return d


d = model(train_set_x, train_set_y, test_set_x, test_set_y, num_iterations=2000, learning_rate=0.005, print_cost=True)


os.makedirs('TestBenchInputFiles', exist_ok=True)

# %% output all the test images
print('writing all input image to text files to ./TestBenchInputFiles')
for index in range(0, m_test - 10):
    my_image1 = (test_set_x[:, index] * 255).astype(int).reshape(test_set_x[:, index].size, 1)
    f = open('TestBenchInputFiles/Image' + str(index) + '.txt', 'w')
    for ii in range(0, my_image1.size):
        #    print(Weights[ii,0]*2**Precision)
        f.write("%i\n" % (my_image1[ii, 0]))
    f.close()

for WEIGHT_BIAS_PRECISION in WeightPrecisionOptions:
    #%% run the design
    Multiplier = 2**WEIGHT_BIAS_PRECISION-1
    Weights = d["w"]
    Bias = d["b"]
    WeightsInt = ((Weights*Multiplier).astype(int)).astype(float)/Multiplier
    BiasInt = ((Bias*Multiplier).astype(int)).astype(float)/Multiplier

    Y_prediction_test = predict(WeightsInt, BiasInt, test_set_x)
    Y_prediction_train = predict(WeightsInt, BiasInt, train_set_x)


    # Print train/test Errors
    print("train accuracy: {} %".format(100 - np.mean(np.abs(Y_prediction_train - train_set_y)) * 100))
    print("test accuracy: {} %".format(100 - np.mean(np.abs(Y_prediction_test - test_set_y)) * 100))

    #%% Your Image
    my_image = "20181028_072807.jpg"   # change this to the name of your image file
    fname = "images/" + my_image
    image1 = np.array(ndimage.imread(fname, flatten=False))
    my_image1 = scipy.misc.imresize(image1, size=(num_px,num_px)).reshape((1, num_px*num_px*3)).T
    plt.imshow(image1)


    #%% image from the data base
    index = 11
    my_image1 = (test_set_x[:,index]*255).astype(int).reshape(test_set_x[:,index].size,1)
    image1=my_image1.reshape((num_px, num_px, 3))
    plt.imshow(image1)
    print ("y = " + str(test_set_y[:, index]) + ", it's a '" + classes[np.squeeze(test_set_y[:, index])].decode("utf-8") +  "' picture.")
    my_predicted_image1 = predict(WeightsInt,BiasInt , my_image1)
    plt.imshow(image1)
    print("y = " + str(np.squeeze(my_predicted_image1)) + ", your algorithm predicts a \"" + classes[int(np.squeeze(my_predicted_image1)),].decode("utf-8") +  "\" picture with a precision of " + str(WEIGHT_BIAS_PRECISION) + " bits.")

    print('outputing golden model results to GoldenModel/ResultsPrecision'+str(WEIGHT_BIAS_PRECISION)+'.txt')

    os.makedirs('GoldenModel', exist_ok=True)
    # output golden model results
    f = open('GoldenModel/ResultsPrecision'+str(WEIGHT_BIAS_PRECISION)+'.txt', 'w')

    for index in range (0,m_test-10):
        f.write("%i\n" % Y_prediction_test[0,index])
       # print(str(index))
        #print(Y_prediction_test[0,index])
    f.close()
    #   plt.imshow(image1)
    #   print("y = " + str(np.squeeze(my_predicted_image1)) + ", your algorithm predicts a \"" + classes[int(np.squeeze(my_predicted_image1)),].decode("utf-8") +  "\" picture with a precision of " + str(Precision) + " bits.")



##################################################  weights file input ##################################################
    os.makedirs('HardwareInputFiles', exist_ok=True)
    print('outputing weights files to HardwareInputFiles/WeightsPrecision'+str(WEIGHT_BIAS_PRECISION)+'.txt')
    #%% output all the the weights and bias
    f = open('HardwareInputFiles/WeightsPrecision'+str(WEIGHT_BIAS_PRECISION)+'.txt', 'w')
    for ii in  range (0,Weights.size):
    #    print(Weights[ii,0]*2**Precision)
        f.write("%i\n" % (Weights[ii,0]*Multiplier))

    f.close()
##################################################  bias file input ##################################################

    print('outputing bias files to HardwareInputFiles/Bias'+str(WEIGHT_BIAS_PRECISION)+'.txt')

    Bias=d["b"]
    f = open('HardwareInputFiles/Bias'+str(WEIGHT_BIAS_PRECISION)+'.txt', 'w')
    for ii in  range (0,Bias.size):
        #print(Bias[ii]*2**WEIGHT_BIAS_PRECISION)
        f.write("%i\n" % (Bias[ii]*Multiplier))

    f.close()


##################################################  include mux file generator ##################################################

os.makedirs('HardwareIncludeFiles', exist_ok=True)

f = open('HardwareIncludeFiles/muxer_include'+str(NUMBER_OF_PIXELS)+'.v', 'w')

for ii in range(0, NUMBER_OF_PIXELS):
    f.write("`AMBA_ADDR_DEPTH'h%i:\n" % ii)
    f.write("begin\n")
    f.write("single_pixel_data = pixdata[(1 + %i) * `PIXEL_PRECISION - 1:(%i) * `PIXEL_PRECISION];\n" %(ii, ii))
    f.write("single_bias_data = bias[(1 + %i) * `WEIGHT_BIAS_PRECISION - 1:(%i) * `WEIGHT_BIAS_PRECISION];\n" %(ii, ii))
    f.write("single_weight_data = weights[(1 + %i) * `WEIGHT_BIAS_PRECISION - 1:(%i) * `WEIGHT_BIAS_PRECISION];\n" %(ii, ii))
    f.write("end\n")

f.close()
##################################################  include sigmoid file generator ##################################################
max_z = 10
min_z = -10
os.makedirs('HardwareIncludeFiles', exist_ok=True)

# sigmoid lut generator

f = open('HardwareIncludeFiles/sigmoid' + str(PIXEL_PRECISION_PLUS_WEIGHT_BIAS_PRECISION) + '.v', 'w')
inputter = np.arange(min_z, max_z, 1/PIXEL_PRECISION_PLUS_WEIGHT_BIAS_PRECISION)
s = 1 / (1 + np.exp(-inputter))
plt.figure('float')
plt.plot(inputter, s, '*')
# plt.show()

z_norm = inputter / ((max_z - min_z) / 2)  # z_norm between -1 and 1
z_norm = np.where(z_norm > 1, 1, z_norm)  # make sure no values exceed 1
z_norm = np.where(z_norm < -1, -1, z_norm)  # make sure no values exceed -1
z_norm_0_to_1 = (z_norm + 1)/2
z_int = (z_norm_0_to_1 * ((2 ** PIXEL_PRECISION_PLUS_WEIGHT_BIAS_PRECISION))).astype(np.int)
s_int = (s * (2 ** PIXEL_PRECISION_PLUS_WEIGHT_BIAS_PRECISION)).astype(np.int)

z_int_unique, indx = np.unique(z_int , return_index=True)
s_int_unique = s_int[indx]
plt.figure('int')
plt.plot(z_int, s_int, '*')
for ii, s_int_current in enumerate(s_int_unique):
    f.write("`PIXEL_PRECISION_PLUS_WEIGHT_BIAS_PRECISION'd%i:\n" % z_int_unique[ii])
    f.write("sigmoidout = `PIXEL_PRECISION_PLUS_WEIGHT_BIAS_PRECISION'd%i;\n" %
            s_int_current)

f.close()
plt.show()